export type NormalizedOffer = {
  id: string;
  price: {
    total: number;
    currency: string;
  };
  itineraries: {
    durationMinutes: number;
    segments: {
      from: string;
      to: string;
      departAt: string;
      arriveAt: string;
      carrierCode: string;
      number: string;
      stops: string[]; // IATA codes of intermediate stops between segments
    }[];
  }[];
  validatingAirlineCodes: string[];
};

function parseISODurationToMinutes(iso: string): number {
  // ISO 8601 like "PT23H20M"
  const m = /PT(?:(\d+)H)?(?:(\d+)M)?/.exec(iso || "");
  if (!m) return 0;
  const h = Number(m[1] || 0);
  const min = Number(m[2] || 0);
  return h * 60 + min;
}

function safeNum(v: unknown, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export function normalizeOffers(amadeusResponse: any): NormalizedOffer[] {
  const data = (amadeusResponse?.data ?? []) as any[];

  return data.map((o: any): NormalizedOffer => {
    const total = safeNum(o?.price?.grandTotal ?? o?.price?.total, 0);
    const currency = String(o?.price?.currency || "USD");

    const itins = (o?.itineraries ?? []).map((it: any) => {
      const segs = (it?.segments ?? []).map((s: any) => {
        const from = String(s?.departure?.iataCode || "");
        const to = String(s?.arrival?.iataCode || "");
        const departAt = String(s?.departure?.at || "");
        const arriveAt = String(s?.arrival?.at || "");
        const carrierCode = String(s?.carrierCode || "");
        const number = String(s?.number || "");
        return { from, to, departAt, arriveAt, carrierCode, number };
      });

      // Collect intermediate stops across multi-segment itineraries
      const stops: string[] = [];
      for (let i = 0; i < segs.length - 1; i++) {
        const stop = segs[i]?.to;
        if (stop) stops.push(stop);
      }

      return {
        durationMinutes: parseISODurationToMinutes(String(it?.duration || "")),
        segments: segs.map((s: any, idx: number) => ({
          ...s,
          stops: idx === 0 ? stops : [],
        })),
      };
    });

    return {
      id: String(o?.id || ""),
      price: { total, currency },
      itineraries: itins,
      validatingAirlineCodes: (o?.validatingAirlineCodes ?? []).map((x: any) => String(x)),
    };
  });
}

export default normalizeOffers;
