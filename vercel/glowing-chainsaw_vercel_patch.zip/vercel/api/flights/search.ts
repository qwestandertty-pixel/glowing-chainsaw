// Vercel Serverless Function (TypeScript)
// Endpoint: POST /api/flights/search

// Avoid hard dependency on @types/node in case the project doesn't have them installed.
declare const process: { env: Record<string, string | undefined> };

type SearchBody = {
  origin: string;
  destination: string;
  departDate: string;   // YYYY-MM-DD
  returnDate?: string;  // YYYY-MM-DD
  adults?: number;
  travelClass?: "ECONOMY" | "PREMIUM_ECONOMY" | "BUSINESS" | "FIRST";
  maxStops?: null | 0 | 1 | 2;
};

// IMPORTANT: .js extension is required for NodeNext ESM builds.
import { normalizeOffers } from "../../shared/normalize.js";

const BASE_URL = (process?.env?.AMADEUS_BASE_URL || "https://test.api.amadeus.com").trim();
const CLIENT_ID = (process?.env?.AMADEUS_CLIENT_ID || "").trim();
const CLIENT_SECRET = (process?.env?.AMADEUS_CLIENT_SECRET || "").trim();

let tokenCache: { access_token: string; expires_at: number } | null = null;

function json(res: any, status: number, body: any) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(JSON.stringify(body));
}

function todayISO(): string {
  const d = new Date();
  // Use UTC date to avoid edge cases around midnight.
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function isISODate(s: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(s);
}

async function getAccessToken(): Promise<string> {
  if (!CLIENT_ID || !CLIENT_SECRET) {
    throw new Error("Missing AMADEUS_CLIENT_ID / AMADEUS_CLIENT_SECRET env vars");
  }

  const now = Date.now();
  if (tokenCache && tokenCache.expires_at > now + 15_000) return tokenCache.access_token;

  const form = new URLSearchParams();
  form.set("grant_type", "client_credentials");
  form.set("client_id", CLIENT_ID);
  form.set("client_secret", CLIENT_SECRET);

  const res = await fetch(`${BASE_URL}/v1/security/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: form.toString(),
  } as any);

  if (!res.ok) {
    const t = await res.text();
    throw new Error(`Token error: ${res.status} \n ${t}`);
  }

  const j = (await res.json()) as any;
  const expiresIn = Number(j.expires_in || 900);
  tokenCache = { access_token: String(j.access_token), expires_at: now + expiresIn * 1000 };
  return tokenCache.access_token;
}

export default async function handler(req: any, res: any) {
  if (req.method !== "POST") return json(res, 405, { error: "Method not allowed" });

  try {
    const body = (req.body || {}) as Partial<SearchBody>;

    const origin = String(body.origin || "").toUpperCase().trim();
    const destination = String(body.destination || "").toUpperCase().trim();
    const departDate = String(body.departDate || "").trim();
    const returnDate = body.returnDate ? String(body.returnDate).trim() : "";

    if (!origin || !destination || !departDate) {
      return json(res, 400, { error: "origin, destination, departDate are required" });
    }
    if (!/^[A-Z0-9]{3}$/.test(origin) || !/^[A-Z0-9]{3}$/.test(destination)) {
      return json(res, 400, { error: "origin/destination must be IATA codes (e.g. MEL, BNA)" });
    }
    if (!isISODate(departDate) || (returnDate && !isISODate(returnDate))) {
      return json(res, 400, { error: "Dates must be YYYY-MM-DD" });
    }

    // Guard: Amadeus rejects past dates.
    const today = todayISO();
    if (departDate <= today) {
      return json(res, 400, {
        error: "INVALID_DATE",
        detail: `departDate must be in the future. Today is ${today}.`,
      });
    }

    const adults = Math.max(1, Math.min(9, Number(body.adults || 1)));
    const travelClass = (body.travelClass || "ECONOMY") as SearchBody["travelClass"];

    const params = new URLSearchParams();
    params.set("originLocationCode", origin);
    params.set("destinationLocationCode", destination);
    params.set("departureDate", departDate);
    if (returnDate) params.set("returnDate", returnDate);
    params.set("adults", String(adults));
    params.set("travelClass", travelClass || "ECONOMY");
    params.set("nonStop", "false");
    params.set("max", "50");

    // Stops filter: Amadeus supports maxNumberOfStops.
    if (body.maxStops !== undefined && body.maxStops !== null) {
      params.set("maxNumberOfStops", String(body.maxStops));
    }

    const token = await getAccessToken();
    const url = `${BASE_URL}/v2/shopping/flight-offers?${params.toString()}`;

    const resp = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    } as any);

    const text = await resp.text();
    if (!resp.ok) {
      // Pass through Amadeus error payload as string to keep it readable in the UI.
      return json(res, resp.status, { error: text });
    }

    const data = JSON.parse(text);
    const offers = normalizeOffers(data);

    return json(res, 200, {
      meta: { origin, destination, departDate, returnDate: returnDate || null, count: offers.length },
      offers,
    });
  } catch (e: any) {
    return json(res, 500, { error: String(e?.message || e) });
  }
}
